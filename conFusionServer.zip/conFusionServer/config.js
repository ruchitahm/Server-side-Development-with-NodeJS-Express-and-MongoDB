module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl' : 'mongodb://localhost:27017/conFusion',
    'facebook': {
        clientId: '700873301526052',
        clientSecret: 'bb3b1f3bdd3c7f9ef31bca6442dec011'
    }
}